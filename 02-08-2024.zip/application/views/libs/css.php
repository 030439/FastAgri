<link rel="stylesheet" href="assets/css/preloader.css" />
<link rel="stylesheet" href="assets/css/font-awesome-pro.css" />
<link rel="stylesheet" href="assets/css/metisMenu.css" />
<link rel="stylesheet" href="assets/css/swiper-bundle.css" />
<link rel="stylesheet" href="assets/css/nice-select.css" />
<link rel="stylesheet" href="assets/css/main.css" />
<!-- <script src="assets/js/tailwind-config.js"></script> -->
<link rel="stylesheet" href="assets/output.css" />
<link rel="stylesheet" href="assets/css/toaster.css" />
<link rel="stylesheet" href="assets/css/datatable.css" />
<link rel="stylesheet" type="text/css" href="assets/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="assets/css/jquery-ui.css">
<style>
    .dt-search{
        float:right;
    }
    .edit{
        padding:5px;
        background-color:#66bfbf;
    }
    .detail{
        padding:5px;
        margin-left:5px;
        background-color:#eaf6f6
    }
    .cashier-menu ul li a {
        padding: 4px 20px; 
    }
    .ui-datepicker-title{
        background-color:#057C89;
        color:#fff;
    }
    .btn-design{
        padding:3px 5px;
        color:#fff; 
        margin:0px 3px;
        border-radius:5px;
    }
    .btn-edit{
        background-color:#009688c9;
    }
    .btn-ledger{
        background-color:#FF9720;
    }
    .btn-detail{
        background-color:#86af49;
    }
    .btn-exp{
        background-color:#ec6f16;
    }
</style>