<div class="cashier-content-area mt-[30px] px-7">
    <div class="cashier-salereturns-area bg-white p-7 custom-shadow rounded-lg pt-5 ">
        <div class="cashier-transection-selectors flex items-center justify-between pb-5 maxSm:block">
            <h4 class="text-[20px] text-heading  font-bold">Expenses</h4>

        </div>

        <div class="cashier-salereturns-table-area">
            <div class="cashier-salereturns-table-innerS">
                    <table id="user-list"  class="table table-bordered borderd table-striped display table-hover">
                        <thead>
                            <tr>
                                <th>Tunnel</th>
                                <th>Expense Type</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Detail</th>
                            </tr>
                        </thead>
                    </table> 
            </div>
        </div>
    </div>
</div>

<?php $file="tunnel-expense.php";?>