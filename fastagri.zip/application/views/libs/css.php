<link rel="stylesheet" href="assets/css/preloader.css" />
<link rel="stylesheet" href="assets/css/font-awesome-pro.css" />
<link rel="stylesheet" href="assets/css/metisMenu.css" />
<link rel="stylesheet" href="assets/css/swiper-bundle.css" />
<link rel="stylesheet" href="assets/css/nice-select.css" />
<link rel="stylesheet" href="assets/css/main.css" />
<!-- <script src="assets/js/tailwind-config.js"></script> -->
<link rel="stylesheet" href="assets/output.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/css/dataTables.dataTables.css" />
  
