<link rel="stylesheet" href="assets/css/preloader.css" />
<link rel="stylesheet" href="assets/css/font-awesome-pro.css" />
<link rel="stylesheet" href="assets/css/metisMenu.css" />
<link rel="stylesheet" href="assets/css/swiper-bundle.css" />
<link rel="stylesheet" href="assets/css/nice-select.css" />
<link rel="stylesheet" href="assets/css/main.css" />
<!-- <script src="assets/js/tailwind-config.js"></script> -->
<link rel="stylesheet" href="assets/output.css" />
<link rel="stylesheet" href="assets/css/toaster.css" />
<link rel="stylesheet" href="assets/css/datatable.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<style>
    .dt-search{
        float:right;
    }
    .edit{
        padding:5px;
        background-color:#66bfbf;
    }
    .detail{
        padding:5px;
        margin-left:5px;
        background-color:#eaf6f6
    }
    .cashier-menu ul li a {
        padding: 4px 20px; 
    }
</style>