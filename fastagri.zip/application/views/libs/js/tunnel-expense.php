<script>
$('#user-list').DataTable({
    responsive: true,
    buttons: ['pageLength', 'excelHtml5', 'csvHtml5', 'pdfHtml5'],
    "processing": true,
    "serverSide": true,
      dom: 'Bfrtip',
         
          "ajax": {
              url : "<?php echo base_url(); ?>tunnels/expenseListing",
              type : 'post',
              error: function(xhr, error, thrown) {
              alert('Error: ' + xhr.responseText);
          }
          },        
           "columns": [
                  { "data": "tunnel" },
                  { "data": "expense_type" },
                  { "data": "amount" },
                  { "data": "edate" },
                  { "data": "edate" }
              ],
              
      });
    </script>