<div class="cashier-content-area mt-[30px] px-7">
    
    <div class="cashier-salereturns-area bg-white p-7 custom-shadow rounded-lg pt-5 ">
            <h4 class="text-[20px] font-bold text-heading" style=" text-align:center">Expeses List</h4>
        <div class="cashier-salereturns-table-area">
            <div class="cashier-salereturns-table-innerS">
                    <table id="user-list"  class="table table-bordered borderd table-striped display table-hover">
                        <thead>
                            <tr>
                                <th>Expense Head</th>
                                <th>Narration </th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th colspan="1"></th>
                            <th >Total</th>
                            <th id="total-net"></th>
                            <th></th>
                        </tr>
                    </tfoot>
                    </table> 
            </div>
        </div>
    </div>
</div>

<?php $file="daily-expense.php";?>