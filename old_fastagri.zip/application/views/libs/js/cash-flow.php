<script src="assets/js/moment.js"></script>

<script>
$(document).ready(function() {
    $(".datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
    var table = $('#user-list').DataTable({
        responsive: true,
        buttons: ['pageLength',  'excelHtml5', 'csvHtml5', 'pdfHtml5'],
        "processing": true,
        "serverSide": true,
        dom: 'Bfrtip',
        "ajax": {
            url: "<?php echo base_url(); ?>cash-flow",
            type: 'post',
            data: function(d) {
                        d.startDate = $('#start-date').val();
                        d.endDate = $('#end-date').val();
                    },
            error: function(xhr, error, thrown) {
                alert('Error: ' + xhr.responseText);
            }
        },
        "columns": [
            {
                "data": null,
                "render": function(data, type, full, meta) {
                    if (full.cash_s === 'cash-in') {
                        return "CR-" + data.id;
                    } else {
                        return "PV-" + data.id;
                    }
                }
            },
            {
                "data": "created_at",
                "render": function(data, type, full, meta) {
                    return moment(data).format('YYYY-MM-DD');
                }
            },
            { "data": "name" },
            { "data": "narration" },
            {
                "data": null,
                "render": function(data, type, full, meta) {
                    if (full.cash_s === 'cash-in') {
                        return full.amount;
                    } else {
                        return '-';
                    }
                }
            },
            {
                "data": null,
                "render": function(data, type, full, meta) {
                    if (full.cash_s === 'cash-out') {
                        return full.amount;
                    } else {
                        return '-';
                    }
                }
            },
            { "data": "famount" },
            {
                "data": "id",
                "render": function(data, type, row) {
                    return '<div style="display:flex"><a class="dropdown-menu-item edit" href="cashbook/invoice/' + data + '"><span>Print</span></a>';
                }
            }
        ]
    });
    $('#filter').on('click', function() {
                table.ajax.reload();
            });
});
</script>
